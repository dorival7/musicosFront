/*
 * Seven Designer - Assets API
 * Ajuste API_BASE_URL somente se seu frontend não usar o mesmo host/base.
 */
const API_BASE_URL = "http://localhost:5297";

function obterToken() {
  const chaves = ["token", "authToken", "accessToken", "tokenMusico"];

  for (const chave of chaves) {
    const valor =
      localStorage.getItem(chave) ||
      sessionStorage.getItem(chave);

    if (valor) {
      return valor.replace(/^Bearer\s+/i, "");
    }
  }

  // Compatibilidade com stores que gravam um objeto JSON de autenticação.
  for (const chave of ["user", "auth", "usuario"]) {
    const bruto =
      localStorage.getItem(chave) ||
      sessionStorage.getItem(chave);

    if (!bruto) continue;

    try {
      const obj = JSON.parse(bruto);
      const token =
        obj?.token ||
        obj?.accessToken ||
        obj?.jwt;

      if (token) {
        return String(token).replace(/^Bearer\s+/i, "");
      }
    } catch {
      // Ignora valores que não são JSON.
    }
  }

  throw new Error(
    "Token do músico não encontrado. Ajuste obterToken() em designerAssetsService.js para a chave usada pelo seu login."
  );
}

async function requisicao(path, options = {}) {
  const token = obterToken();

  const response = await fetch(`${API_BASE_URL}${path}`, {
    ...options,
    headers: {
      Authorization: `Bearer ${token}`,
      ...(options.headers || {})
    }
  });

  const contentType = response.headers.get("content-type") || "";
  const data = contentType.includes("application/json")
    ? await response.json()
    : null;

  if (!response.ok) {
    throw new Error(
      data?.message ||
      data?.title ||
      `Erro HTTP ${response.status}.`
    );
  }

  return data;
}

export async function listarDesignerAssets() {
  return requisicao("/api/tenants/designer-assets");
}

export async function enviarDesignerAsset(file) {
  const formData = new FormData();
  formData.append("file", file);

  return requisicao("/api/tenants/designer-assets", {
    method: "POST",
    body: formData
  });
}

export async function excluirDesignerAsset(id) {
  return requisicao(`/api/tenants/designer-assets/${id}`, {
    method: "DELETE"
  });
}

export function urlDesignerAsset(relativeUrl) {
  if (!relativeUrl) return null;

  if (
    relativeUrl.startsWith("http://") ||
    relativeUrl.startsWith("https://") ||
    relativeUrl.startsWith("blob:")
  ) {
    return relativeUrl;
  }

  return `${API_BASE_URL}${relativeUrl}`;
}
