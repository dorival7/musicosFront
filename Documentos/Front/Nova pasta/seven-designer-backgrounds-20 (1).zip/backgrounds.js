import bg01_rock_stage from "./01-rock-stage.jpg";
import bg02_rock_vintage from "./02-rock-vintage.jpg";
import bg03_rock_grunge from "./03-rock-grunge.jpg";
import bg04_pesqueiro from "./04-pesqueiro.jpg";
import bg05_restaurante_rustico from "./05-restaurante-rustico.jpg";
import bg06_restaurante_moderno from "./06-restaurante-moderno.jpg";
import bg07_pub_rustico from "./07-pub-rustico.jpg";
import bg08_bar_urbano from "./08-bar-urbano.jpg";
import bg09_churrascaria from "./09-churrascaria.jpg";
import bg10_sertanejo from "./10-sertanejo.jpg";
import bg11_country_sunset from "./11-country-sunset.jpg";
import bg12_festa from "./12-festa.jpg";
import bg13_evento_elegante from "./13-evento-elegante.jpg";
import bg14_balada_neon from "./14-balada-neon.jpg";
import bg15_palco_azul from "./15-palco-azul.jpg";
import bg16_palco_vermelho from "./16-palco-vermelho.jpg";
import bg17_palco_verde from "./17-palco-verde.jpg";
import bg18_palco_roxo from "./18-palco-roxo.jpg";
import bg19_luzes_bokeh from "./19-luzes-bokeh.jpg";
import bg20_madeira_escura from "./20-madeira-escura.jpg";

const backgrounds = [
  { id: "classic-gradient", nome: "Clássico", categoria: "padrao", tipo: "procedural", src: null, recomendadoPara: ["sertanejo-sunset"] },
  { id: "01-rock-stage", nome: "Rock Stage", categoria: "rock", tipo: "imagem", src: bg01_rock_stage, recomendadoPara: ["sertanejo-sunset"] },
  { id: "02-rock-vintage", nome: "Rock Vintage", categoria: "rock", tipo: "imagem", src: bg02_rock_vintage, recomendadoPara: ["sertanejo-sunset"] },
  { id: "03-rock-grunge", nome: "Rock Grunge", categoria: "rock", tipo: "imagem", src: bg03_rock_grunge, recomendadoPara: ["sertanejo-sunset"] },
  { id: "04-pesqueiro", nome: "Pesqueiro Sunset", categoria: "pesqueiro", tipo: "imagem", src: bg04_pesqueiro, recomendadoPara: ["sertanejo-sunset"] },
  { id: "05-restaurante-rustico", nome: "Restaurante Rústico", categoria: "restaurante", tipo: "imagem", src: bg05_restaurante_rustico, recomendadoPara: ["sertanejo-sunset"] },
  { id: "06-restaurante-moderno", nome: "Restaurante Moderno", categoria: "restaurante", tipo: "imagem", src: bg06_restaurante_moderno, recomendadoPara: ["sertanejo-sunset"] },
  { id: "07-pub-rustico", nome: "Pub Rústico", categoria: "bar", tipo: "imagem", src: bg07_pub_rustico, recomendadoPara: ["sertanejo-sunset"] },
  { id: "08-bar-urbano", nome: "Bar Urbano", categoria: "bar", tipo: "imagem", src: bg08_bar_urbano, recomendadoPara: ["sertanejo-sunset"] },
  { id: "09-churrascaria", nome: "Churrascaria", categoria: "gastronomia", tipo: "imagem", src: bg09_churrascaria, recomendadoPara: ["sertanejo-sunset"] },
  { id: "10-sertanejo", nome: "Sertanejo Rústico", categoria: "sertanejo", tipo: "imagem", src: bg10_sertanejo, recomendadoPara: ["sertanejo-sunset"] },
  { id: "11-country-sunset", nome: "Country Sunset", categoria: "country", tipo: "imagem", src: bg11_country_sunset, recomendadoPara: ["sertanejo-sunset"] },
  { id: "12-festa", nome: "Festa", categoria: "evento", tipo: "imagem", src: bg12_festa, recomendadoPara: ["sertanejo-sunset"] },
  { id: "13-evento-elegante", nome: "Evento Elegante", categoria: "evento", tipo: "imagem", src: bg13_evento_elegante, recomendadoPara: ["sertanejo-sunset"] },
  { id: "14-balada-neon", nome: "Balada Neon", categoria: "balada", tipo: "imagem", src: bg14_balada_neon, recomendadoPara: ["sertanejo-sunset"] },
  { id: "15-palco-azul", nome: "Palco Azul", categoria: "palco", tipo: "imagem", src: bg15_palco_azul, recomendadoPara: ["sertanejo-sunset"] },
  { id: "16-palco-vermelho", nome: "Palco Vermelho", categoria: "palco", tipo: "imagem", src: bg16_palco_vermelho, recomendadoPara: ["sertanejo-sunset"] },
  { id: "17-palco-verde", nome: "Palco Verde", categoria: "palco", tipo: "imagem", src: bg17_palco_verde, recomendadoPara: ["sertanejo-sunset"] },
  { id: "18-palco-roxo", nome: "Palco Roxo", categoria: "palco", tipo: "imagem", src: bg18_palco_roxo, recomendadoPara: ["sertanejo-sunset"] },
  { id: "19-luzes-bokeh", nome: "Luzes & Bokeh", categoria: "abstrato", tipo: "imagem", src: bg19_luzes_bokeh, recomendadoPara: ["sertanejo-sunset"] },
  { id: "20-madeira-escura", nome: "Madeira Escura", categoria: "textura", tipo: "imagem", src: bg20_madeira_escura, recomendadoPara: ["sertanejo-sunset"] },
];

export function obterBackgroundPorId(id) {
  return backgrounds.find((background) => background.id === id) || backgrounds[0];
}

export function obterBackgroundsDoTemplate(templateId) {
  return backgrounds.filter((background) => !background.recomendadoPara?.length || background.recomendadoPara.includes(templateId));
}

export default backgrounds;
