<template>
  <div class="p7-shell" :class="{ stage: emPalco }">
    <template v-if="!emPalco">
      <div class="p7-intro"><div><h5>🎤 Palco 7</h5><p>Escolha um repertório e leve suas cifras salvas para o palco.</p></div></div>
      <div class="p7-grid"><button v-for="r in repertorios" :key="r.id" class="p7-card" @click="iniciar(r.id)"><strong>{{ r.nome }}</strong><span>{{ r.quantidadeMusicas }} música(s)</span><b>INICIAR MODO PALCO →</b></button></div>
      <div v-if="!repertorios.length" class="p7-empty">Crie primeiro um repertório no <b>Seven Repertório</b>.</div>
    </template>
    <template v-else>
      <div class="stage-top"><button @click="sair">✕ Sair</button><div>{{ repertorio.nome }} · {{ indice + 1 }}/{{ musicas.length }}</div><div class="stage-tools"><div class="layout-toggle" title="Layout da cifra"><button :class="{active:layoutColunas===1}" @click="layoutColunas=1">1 coluna</button><button :class="{active:layoutColunas===2}" @click="layoutColunas=2">2 colunas</button></div><button @click="fonte=Math.max(12,fonte-1)">A−</button><button @click="fonte=Math.min(30,fonte+1)">A+</button><button @click="toggleFull">⛶</button></div></div>
      <div class="stage-song"><div><h2>{{ atual.musica }}</h2><p>{{ atual.artista }}</p></div><div class="stage-tone">TOM {{ atual.tomEscolhido }}</div></div>
      <div ref="scroll" class="stage-scroll" :class="{'duas-colunas':layoutColunas===2}"><template v-if="layoutColunas===2"><pre :style="{fontSize: fonte+'px'}">{{ cifraColunas[0] }}</pre><pre :style="{fontSize: fonte+'px'}">{{ cifraColunas[1] }}</pre></template><pre v-else :style="{fontSize: fonte+'px'}">{{ atual.cifraCompleta }}</pre></div>
      <div class="stage-bottom"><button :disabled="indice===0" @click="anterior">← ANTERIOR</button><button class="list" @click="listaAberta=!listaAberta">🎵 Ver lista de músicas · {{ indice+1 }}/{{ musicas.length }}</button><button :disabled="indice===musicas.length-1" @click="proxima">PRÓXIMA →</button></div>
      <div v-if="listaAberta" class="stage-list">
        <div class="list-head"><div><small>REPERTÓRIO</small><b>Escolha o repertório</b></div><button @click="listaAberta=false">×</button></div>
        <div class="rep-picker">
          <button class="rep-picker-trigger" :disabled="trocandoRepertorio" @click="dropdownAberto=!dropdownAberto">
            <span><small>REPERTÓRIO PARA CONSULTAR</small><b>{{ repertorioPainel ? repertorioPainel.nome : repertorio.nome }}</b></span>
            <span class="rep-count">{{ musicasPainel.length }} música(s)</span>
            <span class="rep-arrow" :class="{open:dropdownAberto}">⌄</span>
          </button>
          <div v-if="dropdownAberto" class="rep-picker-menu">
            <button v-for="r in repertorios" :key="r.id" :class="{selected:String(r.id)===String(repertorioPainel?.id)}" @click="selecionarRepertorioPainel(r.id)">
              <span><b>{{ r.nome }}</b><small>{{ r.quantidadeMusicas }} música(s)</small></span><strong v-if="String(r.id)===String(repertorioPainel?.id)">✓</strong>
            </button>
          </div>
        </div>
        <div class="list-summary"><b>{{ repertorioPainel ? repertorioPainel.nome : repertorio.nome }}</b><span>{{ musicasPainel.length }} música(s)</span></div>
        <button v-for="(m,i) in musicasPainel" :key="m.id" :class="{active:musicaPainelEstaNoPalco(m)}" @click="irPainel(i)"><span>{{ i+1 }}</span><div><b>{{ m.musica }}</b><small>{{ m.artista }}</small></div><strong>{{ m.tomEscolhido }}</strong></button>
        <div v-if="!musicasPainel.length" class="list-empty">Este repertório ainda não possui músicas.</div>
      </div>
    </template>
  </div>
</template>
<script>
import { listarRepertorios, obterRepertorio } from "../seven-repertorio/services/repertoriosService";
export default {
  name:"Palco7",
  data(){return{repertorios:[],repertorio:null,musicas:[],indice:0,emPalco:false,fonte:18,layoutColunas:1,listaAberta:false,trocandoRepertorio:false,repertorioPainel:null,musicasPainel:[],dropdownAberto:false}},
  computed:{
    atual(){return this.musicas[this.indice]||{}},
    cifraColunas(){
      const texto=this.atual.cifraCompleta||"";
      const linhas=texto.split("\n");
      if(linhas.length<2)return[texto,""];
      const meio=Math.ceil(linhas.length/2);
      let corte=meio;
      for(let d=0;d<=Math.min(12,linhas.length);d++){
        const antes=meio-d, depois=meio+d;
        if(antes>0&&antes<linhas.length&&!linhas[antes].trim()){corte=antes+1;break}
        if(depois>0&&depois<linhas.length&&!linhas[depois].trim()){corte=depois+1;break}
      }
      return[linhas.slice(0,corte).join("\n"),linhas.slice(corte).join("\n")];
    }
  },
  mounted(){this.carregar()},
  methods:{
    async carregar(){try{this.repertorios=await listarRepertorios()}catch(e){this.erro(e)}},
    async iniciar(id){try{const r=await obterRepertorio(id);if(!r.musicas?.length)return alert("Este repertório ainda não possui músicas.");this.repertorio=r;this.musicas=r.musicas;this.repertorioPainel=r;this.musicasPainel=r.musicas;this.indice=0;this.emPalco=true;this.$nextTick(()=>this.topo())}catch(e){this.erro(e)}},
    async selecionarRepertorioPainel(id){this.dropdownAberto=false;if(String(id)===String(this.repertorioPainel?.id))return;this.trocandoRepertorio=true;try{const r=await obterRepertorio(id);this.repertorioPainel=r;this.musicasPainel=r.musicas||[]}catch(e){this.erro(e)}finally{this.trocandoRepertorio=false}},
    musicaPainelEstaNoPalco(m){return String(this.repertorioPainel?.id)===String(this.repertorio?.id)&&String(m.id)===String(this.atual?.id)},
    sair(){this.emPalco=false;this.listaAberta=false;this.dropdownAberto=false;this.repertorio=null;this.repertorioPainel=null;this.musicas=[];this.musicasPainel=[];this.carregar()},
    topo(){if(this.$refs.scroll)this.$refs.scroll.scrollTop=0},
    anterior(){if(this.indice>0){this.indice--;this.topo()}},
    proxima(){if(this.indice<this.musicas.length-1){this.indice++;this.topo()}},
    irPainel(i){const m=this.musicasPainel[i];if(!m)return;this.repertorio=this.repertorioPainel;this.musicas=this.musicasPainel;this.indice=i;this.listaAberta=false;this.dropdownAberto=false;this.$nextTick(()=>this.topo())},
    toggleFull(){if(!document.fullscreenElement)this.$el.requestFullscreen?.();else document.exitFullscreen?.()},
    erro(e){console.error(e);alert(e.response?.data?.message||e.message||"Ocorreu um erro.")}
  }
};
</script>
<style scoped>
.p7-intro{background:#fff;border:1px solid #e3e6ec;border-radius:14px;padding:20px;margin-bottom:18px;font-family:monospace}.p7-intro h5{font-weight:900;margin:0}.p7-intro p{margin:5px 0 0;color:#747c88}.p7-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(250px,1fr));gap:14px}.p7-card{background:#15191f;color:#fff;border:1px solid #282f38;border-radius:12px;padding:20px;text-align:left;display:flex;flex-direction:column;gap:8px}.p7-card span{color:#aeb6c2}.p7-card b{color:#ff7a32;font-size:11px;margin-top:10px}.p7-empty{background:#fff;border:1px dashed #ccd2da;border-radius:12px;padding:30px;text-align:center}.stage{position:fixed;inset:0;z-index:9999;background:#0c0f12;color:#f5f7fa;font-family:monospace;display:grid;grid-template-rows:auto auto 1fr auto}.stage-top,.stage-bottom,.stage-song{display:flex;align-items:center;justify-content:space-between;gap:10px}.stage-top{padding:10px 16px;background:#11161b;border-bottom:1px solid #252c34;color:#aeb6c2}.stage-top button,.stage-bottom button{background:#1a2027;color:#fff;border:1px solid #303944;border-radius:8px;padding:9px 13px;font-weight:800}.stage-tools{display:flex;gap:6px;align-items:center}.layout-toggle{display:flex;border:1px solid #303944;border-radius:8px;overflow:hidden;background:#0d1115}.layout-toggle button{border:0!important;border-radius:0!important;background:transparent!important;color:#9da7b2!important;padding:8px 10px!important;min-width:auto!important}.layout-toggle button+button{border-left:1px solid #303944!important}.layout-toggle button.active{background:#ff6c22!important;color:#fff!important}.stage-song{padding:18px 26px 12px}.stage-song h2{font-size:24px;margin:0;color:#fff}.stage-song p{margin:4px 0 0;color:#aeb6c2}.stage-tone{background:#ff6c22;color:#fff;border-radius:8px;padding:9px 13px;font-weight:900}.stage-scroll{overflow:auto;padding:8px 34px 80px}.stage-scroll.duas-colunas{display:grid;grid-template-columns:minmax(0,1fr) minmax(0,1fr);gap:42px;align-items:start}.stage-scroll pre{margin:0;color:#f4f6f8;background:transparent;white-space:pre;font-family:"Courier New",monospace;line-height:1.35;overflow:visible}.stage-bottom{padding:12px 18px;background:#11161b;border-top:1px solid #252c34}.stage-bottom button{min-width:140px}.stage-bottom button:disabled{opacity:.3}.stage-bottom .list{color:#fff;border-color:#ff6c22;background:#20262d;min-width:210px}.stage-bottom .list:hover{background:#292f37}.stage-list{position:fixed;z-index:10001;top:0;bottom:0;right:0;width:min(420px,92vw);background:#11161b;border-left:1px solid #303944;padding:14px;overflow:auto;box-shadow:-20px 0 50px rgba(0,0,0,.4)}.list-head{display:flex;justify-content:space-between;align-items:center;padding:8px 4px 10px}.list-head>div{display:flex;flex-direction:column;gap:3px}.list-head small{font-size:10px;color:#7f8995;letter-spacing:.08em}.list-head b{font-size:13px}.list-head button{background:none;border:0;color:#fff;font-size:26px}.rep-picker{position:relative;margin-bottom:12px}.rep-picker-trigger{width:100%;display:grid;grid-template-columns:1fr auto 24px;gap:10px;align-items:center;text-align:left;background:#171d23;color:#fff;border:1px solid #39434f;border-radius:10px;padding:10px 12px;font-family:monospace;cursor:pointer}.rep-picker-trigger:hover,.rep-picker-trigger:focus{border-color:#ff6c22;outline:none}.rep-picker-trigger>span:first-child{display:flex;flex-direction:column;gap:2px}.rep-picker-trigger small{color:#7f8995;font-size:9px;letter-spacing:.06em}.rep-picker-trigger b{font-size:13px}.rep-count{color:#aeb6c2;font-size:10px}.rep-arrow{font-size:20px;text-align:center;transition:transform .15s}.rep-arrow.open{transform:rotate(180deg)}.rep-picker-menu{position:absolute;z-index:5;left:0;right:0;top:calc(100% + 6px);background:#151a20;border:1px solid #39434f;border-radius:10px;padding:5px;box-shadow:0 14px 32px rgba(0,0,0,.45);max-height:260px;overflow:auto}.rep-picker-menu button{width:100%;display:flex;align-items:center;justify-content:space-between;gap:10px;background:transparent;color:#fff;border:0;border-radius:7px;padding:9px 10px;text-align:left;font-family:monospace;cursor:pointer}.rep-picker-menu button:hover{background:#202730}.rep-picker-menu button.selected{background:#272d34;color:#ff8a4c}.rep-picker-menu button span{display:flex;flex-direction:column;gap:2px}.rep-picker-menu button small{color:#8e98a4;font-size:10px}.rep-picker-menu button strong{color:#ff8a4c}.list-summary{display:flex;justify-content:space-between;align-items:center;color:#aeb6c2;padding:2px 4px 10px;font-size:11px}.list-summary b{color:#fff;font-size:12px}.list-empty{border:1px dashed #303944;border-radius:8px;padding:20px;text-align:center;color:#9099a5}.stage-list>button{width:100%;display:grid;grid-template-columns:32px 1fr 45px;gap:9px;align-items:center;text-align:left;background:#171d23;color:#fff;border:1px solid #282f38;border-radius:8px;padding:10px;margin-bottom:7px}.stage-list>button.active{border-color:#ff6c22}.stage-list small{display:block;color:#9099a5}.stage-list strong{color:#ff8a4c;text-align:right}@media(max-width:600px){.stage-song{padding:14px}.stage-scroll{padding:5px 18px 70px}.stage-scroll.duas-colunas{grid-template-columns:1fr;gap:24px}.layout-toggle{display:none}.stage-bottom button{min-width:0;padding:9px}.stage-top{font-size:11px}.stage-song h2{font-size:19px}}
</style>
